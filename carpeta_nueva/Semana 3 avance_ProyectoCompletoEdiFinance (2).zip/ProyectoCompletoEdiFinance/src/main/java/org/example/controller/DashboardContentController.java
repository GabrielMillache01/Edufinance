package org.example.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class DashboardContentController {

    @FXML
    private Label lblBienvenido;

    @FXML
    private Label lblIngresos;

    @FXML
    private Label lblGastos;

    @FXML
    private Label lblMetas;

    @FXML
    private Button btnAgregarIngreso;

    @FXML
    private Button btnAgregarGasto;

    @FXML
    private Button btnAgregarMeta;

    @FXML
    private Button btnVerReporte;

    // Este método se llama automáticamente al cargar el FXML
    @FXML
    public void initialize() {

        lblIngresos.setText("$0.00");
        lblGastos.setText("$0.00");
        lblMetas.setText("0 metas");
    }

    // Métodos de acción para los botones
    @FXML
    private void handleAgregarIngreso() {
        System.out.println("Botón Agregar Ingreso presionado");
        // Aquí iría la lógica para agregar ingreso
    }

    @FXML
    private void handleAgregarGasto() {
        System.out.println("Botón Agregar Gasto presionado");

    }

    @FXML
    private void handleAgregarMeta() {
        System.out.println("Botón Agregar Meta presionado");

    }

    @FXML
    private void handleVerReporte() {
        System.out.println("Botón Ver Reporte presionado");

    }
}


