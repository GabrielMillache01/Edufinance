package org.example.util;


public interface Calculable {
    double calcular();
}
