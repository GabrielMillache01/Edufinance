package org.example.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import org.example.service.FinanzasService;

import java.time.LocalDate;
import java.util.Arrays;

public class GastoController {

    private FinanzasService servicio;

    @FXML
    private TextField txtId;

    @FXML
    private TextField txtMonto;

    @FXML
    private DatePicker dpFecha;

    @FXML
    private ComboBox<String> cbCategoria;

    @FXML
    private TextField txtDescripcion;

    public void setServicio(FinanzasService servicio) {
        this.servicio = servicio;
    }

    @FXML
    private void initialize() {
        // categorías básicas (puedes cambiar después)
        cbCategoria.getItems().addAll(
                Arrays.asList(
                        "Comida",
                        "Transporte",
                        "Materiales",
                        "Entretenimiento",
                        "Salud",
                        "Otro"
                )
        );
    }

    @FXML
    private void guardarGasto() {
        try {
            String id = txtId.getText();
            double monto = Double.parseDouble(txtMonto.getText());
            LocalDate fecha = dpFecha.getValue();
            String descripcion = txtDescripcion.getText();
            String categoria = cbCategoria.getValue();

            servicio.registrarGasto(id, monto, fecha, descripcion, categoria);

            mostrarMensaje("Gasto guardado correctamente.");
            limpiarCampos();

        } catch (Exception e) {
            mostrarMensaje("Error: " + e.getMessage());
        }
    }

    @FXML
    private void volver() {
        mostrarMensaje("Volviendo al menú (implementar navegación)");
    }

    private void limpiarCampos() {
        txtId.clear();
        txtMonto.clear();
        txtDescripcion.clear();
        dpFecha.setValue(null);
        cbCategoria.setValue(null);
    }

    private void mostrarMensaje(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}


