package org.example.model;

public class ReporteFinanciero {

    private final String id;
    private final double totalIngresos;
    private final double totalGastos;

    public ReporteFinanciero(String id,
                             double totalIngresos,
                             double totalGastos) {

        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("El id del reporte no puede estar vacío.");
        }
        if (totalIngresos < 0) {
            throw new IllegalArgumentException("El total de ingresos no puede ser negativo.");
        }
        if (totalGastos < 0) {
            throw new IllegalArgumentException("El total de gastos no puede ser negativo.");
        }

        this.id = id;
        this.totalIngresos = totalIngresos;
        this.totalGastos = totalGastos;
    }

    public String getId() {
        return id;
    }

    public double getTotalIngresos() {
        return totalIngresos;
    }

    public double getTotalGastos() {
        return totalGastos;
    }

    public double getBalance() {
        return totalIngresos - totalGastos;
    }

    public boolean tieneSuperavit() {
        return getBalance() > 0;
    }

    public boolean tieneDeficit() {
        return getBalance() < 0;
    }

    @Override
    public String toString() {
        return "ReporteFinanciero{" +
                "id='" + id + '\'' +
                ", ingresos=" + totalIngresos +
                ", gastos=" + totalGastos +
                ", balance=" + getBalance() +
                '}';
    }
}



