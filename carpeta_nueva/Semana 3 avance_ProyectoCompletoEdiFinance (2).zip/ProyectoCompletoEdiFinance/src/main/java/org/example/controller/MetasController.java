package org.example.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import org.example.service.FinanzasService;

import java.time.LocalDate;

public class MetasController {

    private FinanzasService servicio;

    @FXML
    private TextField txtObjetivo;
    @FXML
    private TextField txtDescripcion;
    @FXML
    private TextField txtFechaLimite;
    @FXML
    private TextField txtMontoAgregar;
    @FXML
    private Label lblProgreso;
    @FXML
    private Button btnCrear;
    @FXML
    private Button btnAgregar;

    public void initialize() {
        System.out.println("Vista metas cargada");
    }

    public void setServicio(FinanzasService servicio) {
        this.servicio = servicio;
        actualizarProgreso();
    }

    @FXML
    private void crearMeta() {
        try {
            double objetivo = Double.parseDouble(txtObjetivo.getText());
            LocalDate fecha = LocalDate.parse(txtFechaLimite.getText());
            String descripcion = txtDescripcion.getText();

            servicio.crearMetaAhorro(objetivo, fecha, descripcion);
            mensaje("Meta creada correctamente");
            actualizarProgreso();
        } catch (Exception e) {
            mensaje(e.getMessage());
        }
    }

    @FXML
    private void agregarAhorro() {
        try {
            double monto = Double.parseDouble(txtMontoAgregar.getText());
            servicio.agregarAhorroMetaActual(monto);
            mensaje("Ahorro agregado");
            actualizarProgreso();
        } catch (Exception e) {
            mensaje(e.getMessage());
        }
    }

    private void actualizarProgreso() {
        servicio.obtenerMetaActual().ifPresent(meta ->
                lblProgreso.setText(meta.getAhorroActual() + " / " + meta.getObjetivo())
        );
    }

    private void mensaje(String m) {
        var alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setContentText(m);
        alerta.show();
    }
}
