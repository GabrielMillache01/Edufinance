package org.example.model;

import java.time.LocalDate;

public class MetaAhorro {

    private final String id;
    private final double objetivo;
    private double ahorroActual;
    private final LocalDate fechaLimite;
    private final String descripcion;

    public MetaAhorro(String id, double objetivo, LocalDate fechaLimite, String descripcion) {

        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("ID no puede estar vacío.");
        }

        if (objetivo <= 0) {
            throw new IllegalArgumentException("El objetivo debe ser mayor que 0.");
        }

        if (fechaLimite == null || fechaLimite.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("La fecha límite debe ser futura.");
        }

        this.id = id;
        this.objetivo = objetivo;
        this.fechaLimite = fechaLimite;
        this.descripcion = descripcion;
        this.ahorroActual = 0;
    }

    public void agregarAhorro(double monto) {

        if (monto <= 0) {
            throw new IllegalArgumentException("El monto debe ser mayor que 0.");
        }

        if (ahorroActual + monto > objetivo) {
            throw new IllegalArgumentException("No se puede agregar, supera la meta.");
        }

        this.ahorroActual += monto;
    }

    public boolean estaCompletada() {
        return ahorroActual >= objetivo;
    }

    public String getId() {
        return id;
    }

    public double getObjetivo() {
        return objetivo;
    }

    public double getAhorroActual() {
        return ahorroActual;
    }

    public LocalDate getFechaLimite() {
        return fechaLimite;
    }

    public String getDescripcion() {
        return descripcion;
    }


    public double getPorcentaje() {
        return (ahorroActual / objetivo) * 100.0;
    }

    public double getRestante() {
        return objetivo - ahorroActual;
    }

    public long diasRestantes() {
        return fechaLimite.toEpochDay() - LocalDate.now().toEpochDay();
    }

    public boolean estaVencida() {
        return LocalDate.now().isAfter(fechaLimite) && !estaCompletada();
    }
}



