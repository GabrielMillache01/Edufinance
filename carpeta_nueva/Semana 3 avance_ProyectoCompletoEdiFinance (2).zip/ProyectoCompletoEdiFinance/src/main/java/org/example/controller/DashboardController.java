package org.example.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

public class DashboardController {

    @FXML
    private StackPane contentArea;

    public void openIngresos() throws Exception {
        loadView("ingresos.fxml");
    }

    public void openGastos() throws Exception {
        loadView("gastos.fxml");
    }

    public void openMetas() throws Exception {
        loadView("metas.fxml");
    }

    private void loadView(String name) throws Exception {
        Parent pane = FXMLLoader.load(
                getClass().getResource("/view/" + name)
        );
        contentArea.getChildren().setAll(pane);
    }

}



