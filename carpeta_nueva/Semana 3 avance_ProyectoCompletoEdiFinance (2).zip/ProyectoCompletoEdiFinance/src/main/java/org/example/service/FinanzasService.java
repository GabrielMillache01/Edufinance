package org.example.service;

import org.example.model.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public class FinanzasService {

    private final Estudiante estudiante;

    public FinanzasService(Estudiante estudiante) {
        this.estudiante = estudiante;
    }


    public Ingreso registrarIngreso(String id, double monto, LocalDate fecha, String descripcion) {
        Ingreso ingreso = new Ingreso(id, monto, fecha, descripcion);
        ingreso.validar();
        estudiante.agregarTransaccion(ingreso);
        return ingreso;
    }

    public List<Ingreso> obtenerIngresos() {
        List<Ingreso> lista = new ArrayList<>();
        for (Transaccion t : estudiante.getTransacciones()) {
            if (t instanceof Ingreso) lista.add((Ingreso) t);
        }
        return lista;
    }

    public double totalIngresos() {
        return obtenerIngresos().stream().mapToDouble(Ingreso::getMonto).sum();
    }


    public Gasto registrarGasto(String id, double monto, LocalDate fecha, String descripcion, String categoria) {
        Gasto gasto = new Gasto(id, monto, fecha, descripcion, categoria);
        gasto.validar();
        estudiante.agregarTransaccion(gasto);
        return gasto;
    }

    public List<Gasto> obtenerGastos() {
        List<Gasto> lista = new ArrayList<>();
        for (Transaccion t : estudiante.getTransacciones()) {
            if (t instanceof Gasto) lista.add((Gasto) t);
        }
        return lista;
    }

    public double totalGastos() {
        return obtenerGastos().stream().mapToDouble(Gasto::getMonto).sum();
    }


    public MetaAhorro crearMetaAhorro(String id, double objetivo, LocalDate fechaLimite, String descripcion) {
        MetaAhorro meta = new MetaAhorro(id, objetivo, fechaLimite, descripcion);
        estudiante.agregarMetaAhorro(meta);
        return meta;
    }

    public MetaAhorro crearMetaAhorro(double objetivo, LocalDate fechaLimite, String descripcion) {
        String id = "m-" + UUID.randomUUID().toString();
        return crearMetaAhorro(id, objetivo, fechaLimite, descripcion);
    }

    public List<MetaAhorro> obtenerMetas() {
        return estudiante.getMetasAhorro();
    }

    public Optional<MetaAhorro> buscarMeta(String idMeta) {
        return estudiante.getMetasAhorro()
                .stream()
                .filter(m -> m.getId().equals(idMeta))
                .findFirst();
    }

    public void agregarAhorroAMeta(String idMeta, double monto) {
        MetaAhorro meta = buscarMeta(idMeta)
                .orElseThrow(() -> new IllegalArgumentException("Meta no encontrada: " + idMeta));
        meta.agregarAhorro(monto);
    }

    public Optional<MetaAhorro> obtenerMetaActual() {
        List<MetaAhorro> metas = obtenerMetas();
        if (metas.isEmpty()) return Optional.empty();
        return Optional.of(metas.get(metas.size() - 1));
    }

    public void agregarAhorroMetaActual(double monto) {
        MetaAhorro meta = obtenerMetaActual()
                .orElseThrow(() -> new IllegalStateException("No hay meta creada aún."));
        agregarAhorroAMeta(meta.getId(), monto);
    }

    // Reportes
    public ReporteFinanciero generarReporte(String idReporte) {
        double ingresos = totalIngresos();
        double gastos = totalGastos();
        ReporteFinanciero reporte = new ReporteFinanciero(idReporte, ingresos, gastos);
        estudiante.agregarReporte(reporte);
        return reporte;
    }

    public List<ReporteFinanciero> obtenerReportes() {
        return estudiante.getReportes();
    }

    public double calcularBalanceActual() {
        return totalIngresos() - totalGastos();
    }
}
