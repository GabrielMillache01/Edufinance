package org.example.firebase;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.auth.oauth2.GoogleCredentials;

import java.io.InputStream;

public class FirebaseInitializer {

    public static void inicializarFirebase() {
        try {

            InputStream serviceAccount = FirebaseInitializer.class
                    .getResourceAsStream("/firebase/nuevoproyectoedufinance-firebase-adminsdk-fbsvc-42a7d681c5.json");

            FirebaseOptions options = FirebaseOptions.builder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                    .setDatabaseUrl("https://nuevoproyectoedufinance-default-rtdb.firebaseio.com/")
                    .build();

            if (FirebaseApp.getApps().isEmpty()) {
                FirebaseApp.initializeApp(options);
            }

            System.out.println("Firebase inicializado correctamente!");

        } catch (Exception e) {
            System.out.println("Error inicializando Firebase");
            e.printStackTrace();
        }
    }
}


