package org.example.model;

import java.time.LocalDate;

public abstract class Transaccion {

    protected String id;
    protected double monto;
    protected LocalDate fecha;
    protected String descripcion;

    public Transaccion(String id, double monto, LocalDate fecha, String descripcion) {
        this.id = id;
        this.monto = monto;
        this.fecha = fecha;
        this.descripcion = descripcion;
    }

    public abstract void validar();

    public String getId() {
        return id;
    }

    public double getMonto() {
        return monto;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public String getDescripcion() {
        return descripcion;
    }
}




