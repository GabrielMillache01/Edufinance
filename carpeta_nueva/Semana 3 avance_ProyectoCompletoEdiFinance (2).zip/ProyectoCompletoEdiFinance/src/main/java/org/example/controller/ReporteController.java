package org.example.controller;

public class ReporteController {

    public void initialize() {
        System.out.println("Vista reporte cargada");
    }
}
