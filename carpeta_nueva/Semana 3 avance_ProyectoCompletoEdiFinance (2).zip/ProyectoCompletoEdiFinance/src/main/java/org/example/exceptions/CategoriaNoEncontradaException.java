package org.example.exceptions;

public class CategoriaNoEncontradaException extends Exception {

    public CategoriaNoEncontradaException(String mensaje) {
        super(mensaje);
    }
}
