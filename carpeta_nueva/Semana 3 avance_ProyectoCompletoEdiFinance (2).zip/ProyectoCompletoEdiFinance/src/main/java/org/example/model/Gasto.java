package org.example.model;

import java.time.LocalDate;

public class Gasto extends Transaccion {

    private String categoria;

    public Gasto(String id,
                 double monto,
                 LocalDate fecha,
                 String descripcion,
                 String categoria) {
        super(id, monto, fecha, descripcion);
        this.categoria = categoria;
    }

    @Override
    public void validar() {
        if (categoria == null || categoria.isBlank()) {
            throw new IllegalArgumentException("El gasto debe tener categoría.");
        }
    }

    public String getCategoria() {
        return categoria;
    }
}





