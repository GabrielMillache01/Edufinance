package org.example.model;

import java.util.ArrayList;
import java.util.List;

public class Estudiante {

    private String id;
    private String nombre;
    private List<Transaccion> transacciones;
    private List<MetaAhorro> metasAhorro;
    private List<ReporteFinanciero> reportes;

    public Estudiante(String id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.transacciones = new ArrayList<>();
        this.metasAhorro = new ArrayList<>();
        this.reportes = new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public List<Transaccion> getTransacciones() {
        return transacciones;
    }

    public List<MetaAhorro> getMetasAhorro() {
        return metasAhorro;
    }

    public List<ReporteFinanciero> getReportes() {
        return reportes;
    }

    public void agregarTransaccion(Transaccion t) {
        t.validar();
        transacciones.add(t);
    }

    public void eliminarTransaccion(String id) {
        transacciones.removeIf(t -> t.getId().equals(id));
    }

    public void agregarMetaAhorro(MetaAhorro meta) {
        metasAhorro.add(meta);
    }

    public void agregarReporte(ReporteFinanciero r) {
        reportes.add(r);
    }
}
