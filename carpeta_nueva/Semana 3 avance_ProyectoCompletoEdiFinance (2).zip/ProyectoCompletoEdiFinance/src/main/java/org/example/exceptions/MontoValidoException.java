package org.example.exceptions;

public class MontoValidoException extends Exception {

    public MontoValidoException(String mensaje) {
        super(mensaje);
    }
}
