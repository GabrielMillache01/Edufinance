package org.example.exceptions;

public class MetaAhorroSuperadaException extends Exception {

    public MetaAhorroSuperadaException(String mensaje) {
        super(mensaje);
    }
}
