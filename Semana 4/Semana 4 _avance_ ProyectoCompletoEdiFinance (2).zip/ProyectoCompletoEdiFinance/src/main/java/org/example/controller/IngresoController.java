package org.example.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import org.example.service.FinanzasService;

import java.time.LocalDate;

public class IngresoController {

    private FinanzasService servicio;

    @FXML private TextField txtId, txtMonto, txtDescripcion;
    @FXML private DatePicker dpFecha;

    public void setServicio(FinanzasService servicio) {
        this.servicio = servicio;
    }

    @FXML
    public void guardarIngreso() {
        try {
            servicio.registrarIngreso(
                    txtId.getText(),
                    Double.parseDouble(txtMonto.getText()),
                    dpFecha.getValue(),
                    txtDescripcion.getText()
            );
            mostrarMensaje("Ingreso guardado correctamente");
            limpiarCampos();
        } catch (Exception e) {
            mostrarMensaje("Error: " + e.getMessage());
        }
    }

    private void limpiarCampos() {
        txtId.clear(); txtMonto.clear(); txtDescripcion.clear(); dpFecha.setValue(null);
    }

    private void mostrarMensaje(String m) {
        new Alert(Alert.AlertType.INFORMATION, m).show();
    }
}


