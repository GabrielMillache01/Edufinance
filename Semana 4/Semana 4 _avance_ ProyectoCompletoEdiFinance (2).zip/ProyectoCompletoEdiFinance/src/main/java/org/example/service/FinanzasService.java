package org.example.service;

import org.example.model.*;
import org.example.config.FirebaseConfig;
import com.google.firebase.database.DatabaseReference;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class FinanzasService {

    private final Estudiante estudiante;
    private final DatabaseReference db;

    public FinanzasService(Estudiante estudiante) {
        this.estudiante = estudiante;
        this.db = FirebaseConfig.getDB().getReference();
    }

    // Ingresos
    public Ingreso registrarIngreso(String id, double monto, LocalDate fecha, String descripcion) {
        Ingreso ingreso = new Ingreso(id, monto, fecha, descripcion);
        ingreso.validar();
        estudiante.agregarTransaccion(ingreso);

        db.child("ingresos").push().setValueAsync(Map.of(
                "id", ingreso.getId(),
                "monto", ingreso.getMonto(),
                "fecha", ingreso.getFecha().toString(),
                "descripcion", ingreso.getDescripcion()
        ));

        return ingreso;
    }

    public List<Ingreso> obtenerIngresos() {
        return estudiante.getTransacciones().stream()
                .filter(t -> t instanceof Ingreso)
                .map(t -> (Ingreso) t)
                .collect(Collectors.toList());
    }

    public double totalIngresos() {
        return obtenerIngresos().stream().mapToDouble(Ingreso::getMonto).sum();
    }

    // Gastos
    public Gasto registrarGasto(String id, double monto, LocalDate fecha, String descripcion, String categoria) {
        Gasto gasto = new Gasto(id, monto, fecha, descripcion, categoria);
        gasto.validar();
        estudiante.agregarTransaccion(gasto);

        db.child("gastos").push().setValueAsync(Map.of(
                "id", gasto.getId(),
                "monto", gasto.getMonto(),
                "fecha", gasto.getFecha().toString(),
                "descripcion", gasto.getDescripcion(),
                "categoria", gasto.getCategoria()
        ));

        return gasto;
    }

    public List<Gasto> obtenerGastos() {
        return estudiante.getTransacciones().stream()
                .filter(t -> t instanceof Gasto)
                .map(t -> (Gasto) t)
                .collect(Collectors.toList());
    }

    public double totalGastos() {
        return obtenerGastos().stream().mapToDouble(Gasto::getMonto).sum();
    }

    // Metas
    public MetaAhorro crearMetaAhorro(String id, double objetivo, LocalDate fechaLimite, String descripcion) {
        MetaAhorro meta = new MetaAhorro(id, objetivo, fechaLimite, descripcion);
        estudiante.agregarMetaAhorro(meta);

        db.child("metas").push().setValueAsync(Map.of(
                "id", meta.getId(),
                "objetivo", meta.getObjetivo(),
                "fechaLimite", meta.getFechaLimite().toString(),
                "descripcion", meta.getDescripcion(),
                "ahorroActual", meta.getAhorroActual()
        ));

        return meta;
    }

    public MetaAhorro crearMetaAhorro(double objetivo, LocalDate fechaLimite, String descripcion) {
        String id = "m-" + UUID.randomUUID();
        return crearMetaAhorro(id, objetivo, fechaLimite, descripcion);
    }

    public List<MetaAhorro> obtenerMetas() {
        return estudiante.getMetasAhorro();
    }

    public Optional<MetaAhorro> obtenerMetaActual() {
        return obtenerMetas().stream().reduce((first, second) -> second);
    }

    public void agregarAhorroMetaActual(double monto) {
        MetaAhorro meta = obtenerMetaActual()
                .orElseThrow(() -> new IllegalStateException("No hay meta creada aún."));
        meta.agregarAhorro(monto);

        db.child("metas").child(meta.getId()).child("ahorroActual")
                .setValueAsync(meta.getAhorroActual());
    }

    // Reportes
    public ReporteFinanciero generarReporte(String idReporte) {
        double ingresos = totalIngresos();
        double gastos = totalGastos();
        ReporteFinanciero reporte = new ReporteFinanciero(idReporte, ingresos, gastos);
        estudiante.agregarReporte(reporte);
        return reporte;
    }

    public List<ReporteFinanciero> obtenerReportes() {
        return estudiante.getReportes();
    }

    public double calcularBalanceActual() {
        return totalIngresos() - totalGastos();
    }
}
