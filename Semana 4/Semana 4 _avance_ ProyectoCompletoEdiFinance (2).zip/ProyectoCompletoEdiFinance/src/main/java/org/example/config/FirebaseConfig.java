package org.example.config;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.database.FirebaseDatabase;

import java.io.InputStream;

public class FirebaseConfig {

    private static boolean inicializado = false;

    public static void init() {
        if (inicializado) return;

        try {
            InputStream serviceAccount =
                    FirebaseConfig.class.getResourceAsStream("/firebase/firebase.json");

            if (serviceAccount == null) {
                throw new RuntimeException("No se encontró firebase.json en resources/firebase/");
            }

            FirebaseOptions options = FirebaseOptions.builder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                    .setDatabaseUrl("https://nuevoproyectoedufinance-default-rtdb.firebaseio.com")
                    .build();

            FirebaseApp.initializeApp(options);
            FirebaseDatabase.getInstance().setPersistenceEnabled(true);

            inicializado = true;
            System.out.println(" Firebase conectado correctamente");

        } catch (Exception e) {
            throw new RuntimeException("Error al inicializar Firebase: " + e.getMessage(), e);
        }
    }

    public static FirebaseDatabase getDB() {
        init();
        return FirebaseDatabase.getInstance();
    }
}
