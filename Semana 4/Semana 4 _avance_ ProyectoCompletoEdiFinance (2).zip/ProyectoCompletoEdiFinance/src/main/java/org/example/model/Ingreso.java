package org.example.model;
import java.time.LocalDate;

public class Ingreso extends Transaccion {

    public Ingreso(String id, double monto, LocalDate fecha, String descripcion) {
        super(id, monto, fecha, descripcion);
    }

    @Override
    public void validar() {
        if (getMonto() <= 0) {
            throw new IllegalArgumentException("El monto del ingreso debe ser mayor a 0.");
        }
    }
}

