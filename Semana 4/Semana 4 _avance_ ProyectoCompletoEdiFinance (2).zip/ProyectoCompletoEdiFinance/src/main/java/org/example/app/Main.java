package org.example.app;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.example.controller.DashboardController;
import org.example.service.FinanzasService;
import org.example.config.FirebaseConfig;
import org.example.model.Estudiante;

public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        FirebaseConfig.init();
        Estudiante estudiante = new Estudiante("e-001", "Usuario Ejemplo");

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/dashboard.fxml"));
        Parent root = loader.load();

        DashboardController controller = loader.getController();
        controller.setServicio(new FinanzasService(estudiante));

        stage.setTitle("EduFinance");
        stage.setScene(new Scene(root));
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}

