package org.example.app;

public class MainApp {
}
