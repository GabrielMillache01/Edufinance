package org.example.firebase;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.auth.oauth2.GoogleCredentials;

import java.io.InputStream;

public class FirebaseInitializer {

    public static void inicializarFirebase() {
        System.out.println("----- FirebaseInitializer: buscando firebase.json en resources -----");

        try {

            InputStream serviceAccount = FirebaseInitializer.class.getClassLoader()
                    .getResourceAsStream("firebase/firebase.json");


            java.net.URL url = FirebaseInitializer.class.getClassLoader().getResource("firebase/firebase.json");
            System.out.println("Firebase json URL (ClassLoader.getResource): " + url);

            if (serviceAccount == null) {
                throw new RuntimeException("No se encontró firebase.json en resources/firebase/ (revisa que esté en src/main/resources/firebase/firebase.json y que el resources root esté marcado).");
            }

            FirebaseOptions options = FirebaseOptions.builder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                    .setDatabaseUrl("https://nuevoproyectoedufinance-default-rtdb.firebaseio.com/")
                    .build();

            if (FirebaseApp.getApps().isEmpty()) {
                FirebaseApp.initializeApp(options);
            }

            System.out.println("Firebase inicializado correctamente!");
        } catch (Exception e) {
            System.out.println("Error inicializando Firebase:");
            e.printStackTrace();

        }
    }
}

