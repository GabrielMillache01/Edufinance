package org.example.repository;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import org.example.model.Ingreso;
import org.example.model.Gasto;

public class FirebaseRepository {

    private final DatabaseReference db;

    public FirebaseRepository() {
        this.db = FirebaseDatabase.getInstance().getReference();
    }


    public void guardarIngreso(Ingreso ingreso) {
        db.child("ingresos")
                .child(ingreso.getId())
                .setValueAsync(ingreso);
    }

    public void eliminarIngreso(String id) {
        db.child("ingresos")
                .child(id)
                .removeValueAsync();
    }


    public void guardarGasto(Gasto gasto) {
        db.child("gastos")
                .child(gasto.getId())
                .setValueAsync(gasto);
    }

    public void eliminarGasto(String id) {
        db.child("gastos")
                .child(id)
                .removeValueAsync();
    }
}

