package org.example.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import org.example.service.FinanzasService;
import org.example.model.ReporteFinanciero;

import java.util.List;

public class ReporteController {

    private FinanzasService servicio;

    @FXML private TextArea txtReporte;

    public void setServicio(FinanzasService servicio) {
        this.servicio = servicio;
        mostrarReporte();
    }

    @FXML
    private void mostrarReporte() {
        List<ReporteFinanciero> reportes = servicio.obtenerReportes();
        StringBuilder sb = new StringBuilder();

        if(reportes.isEmpty()) {
            txtReporte.setText("No hay reportes generados aún.");
            return;
        }

        reportes.forEach(r -> sb.append("Reporte ID: ").append(r.getId()).append("\n")
                .append("Total Ingresos: ").append(r.getTotalIngresos()).append("\n")
                .append("Total Gastos: ").append(r.getTotalGastos()).append("\n")
                .append("Balance: ").append(r.getTotalIngresos() - r.getTotalGastos()).append("\n")
                .append("-------------------------------\n")
        );

        txtReporte.setText(sb.toString());
    }

    @FXML
    private void generarNuevoReporte() {
        try {
            String id = "r-" + System.currentTimeMillis();
            servicio.generarReporte(id);
            mostrarReporte();
            mostrarMensaje("Reporte generado correctamente");
        } catch (Exception e) {
            mostrarMensaje("Error: " + e.getMessage());
        }
    }

    private void mostrarMensaje(String m) {
        new Alert(Alert.AlertType.INFORMATION, m).show();
    }
}

