package org.example.service;

import com.google.firebase.database.DatabaseReference;
import org.example.firebase.DatabaseConfig;
import org.example.model.Ingreso;

import java.time.LocalDate;
import java.util.UUID;

public class IngresoService {

    public static void guardarIngreso(double monto, String descripcion) {

        String id = UUID.randomUUID().toString();

        Ingreso ingreso = new Ingreso(
                id,
                monto,
                LocalDate.now(),
                descripcion
        );

        ingreso.validar(); // porque tu clase lo exige

        DatabaseReference db = DatabaseConfig.getDB();

        db.child("ingresos")
                .child(id)
                .setValueAsync(ingreso);

        System.out.println("Ingreso guardado ✔");
    }
}

