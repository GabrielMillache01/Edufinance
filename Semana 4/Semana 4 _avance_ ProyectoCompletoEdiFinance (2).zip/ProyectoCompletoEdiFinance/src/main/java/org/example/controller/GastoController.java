package org.example.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import org.example.service.FinanzasService;
import java.util.Arrays;

public class GastoController {

    private FinanzasService servicio;

    @FXML private TextField txtId, txtMonto, txtDescripcion;
    @FXML private DatePicker dpFecha;
    @FXML private ComboBox<String> cbCategoria;

    public void setServicio(FinanzasService servicio) { this.servicio = servicio; }

    @FXML
    public void initialize() {
        cbCategoria.getItems().addAll(Arrays.asList(
                "Comida","Transporte","Materiales","Entretenimiento","Salud","Otro"));
    }

    @FXML
    public void guardarGasto() {
        try {
            servicio.registrarGasto(
                    txtId.getText(),
                    Double.parseDouble(txtMonto.getText()),
                    dpFecha.getValue(),
                    txtDescripcion.getText(),
                    cbCategoria.getValue()
            );
            mensaje("Gasto guardado correctamente");
            limpiar();
        } catch (Exception e) {
            mensaje(e.getMessage());
        }
    }

    private void limpiar() {
        txtId.clear(); txtMonto.clear(); txtDescripcion.clear();
        dpFecha.setValue(null); cbCategoria.setValue(null);
    }

    private void mensaje(String m) {
        new Alert(Alert.AlertType.INFORMATION, m).show();
    }
}



