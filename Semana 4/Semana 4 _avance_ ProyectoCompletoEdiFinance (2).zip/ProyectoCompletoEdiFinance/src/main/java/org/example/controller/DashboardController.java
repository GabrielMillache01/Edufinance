package org.example.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import org.example.service.FinanzasService;

public class DashboardController {

    private FinanzasService servicio;

    @FXML private Label lblTotalIngresos;
    @FXML private Label lblTotalGastos;
    @FXML private Label lblBalance;
    @FXML private Label lblMetaActual;

    public void setServicio(FinanzasService servicio) {
        this.servicio = servicio;
        actualizarDashboard();
    }

    @FXML
    public void actualizarDashboard() {
        // Programación funcional para totales
        lblTotalIngresos.setText(String.format("$%.2f", servicio.totalIngresos()));
        lblTotalGastos.setText(String.format("$%.2f", servicio.totalGastos()));
        lblBalance.setText(String.format("$%.2f", servicio.calcularBalanceActual()));

        // Meta actual
        servicio.obtenerMetaActual()
                .ifPresentOrElse(
                        meta -> lblMetaActual.setText(
                                String.format("%s: %.2f / %.2f (%.1f%%)",
                                        meta.getDescripcion(),
                                        meta.getAhorroActual(),
                                        meta.getObjetivo(),
                                        meta.getPorcentaje())
                        ),
                        () -> lblMetaActual.setText("No hay meta activa")
                );
    }
}

