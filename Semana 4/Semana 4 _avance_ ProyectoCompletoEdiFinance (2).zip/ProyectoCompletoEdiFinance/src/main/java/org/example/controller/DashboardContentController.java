package org.example.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import org.example.service.FinanzasService;

public class DashboardContentController {

    private FinanzasService servicio;

    @FXML private Label lblBienvenido;
    @FXML private Label lblIngresos;
    @FXML private Label lblGastos;
    @FXML private Label lblMetas;
    @FXML private Button btnAgregarIngreso;
    @FXML private Button btnAgregarGasto;
    @FXML private Button btnAgregarMeta;
    @FXML private Button btnVerReporte;

    public void setServicio(FinanzasService servicio) {
        this.servicio = servicio;
        actualizarDashboard();
    }

    @FXML
    public void initialize() {
        lblIngresos.setText("$0.00");
        lblGastos.setText("$0.00");
        lblMetas.setText("0 metas");
    }

    private void actualizarDashboard() {
        lblIngresos.setText(String.format("$%.2f", servicio.totalIngresos()));
        lblGastos.setText(String.format("$%.2f", servicio.totalGastos()));
        lblMetas.setText(servicio.obtenerMetas().size() + " metas");
    }

    @FXML
    private void handleAgregarIngreso() {
        System.out.println("Botón Agregar Ingreso presionado");
        actualizarDashboard();
    }

    @FXML
    private void handleAgregarGasto() {
        System.out.println("Botón Agregar Gasto presionado");
        actualizarDashboard();
    }

    @FXML
    private void handleAgregarMeta() {
        System.out.println("Botón Agregar Meta presionado");
        actualizarDashboard();
    }

    @FXML
    private void handleVerReporte() {
        System.out.println("Botón Ver Reporte presionado");
    }
}

