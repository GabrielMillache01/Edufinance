package org.example.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import org.example.service.FinanzasService;

import java.time.LocalDate;

public class MetasController {

    private FinanzasService servicio;

    @FXML private TextField txtObjetivo, txtDescripcion, txtFechaLimite, txtMontoAgregar;
    @FXML private Label lblProgreso;
    @FXML private Button btnCrear, btnAgregar;

    public void setServicio(FinanzasService servicio) {
        this.servicio = servicio;
        actualizarProgreso();
    }

    @FXML
    private void crearMeta() {
        try {
            servicio.crearMetaAhorro(
                    Double.parseDouble(txtObjetivo.getText()),
                    LocalDate.parse(txtFechaLimite.getText()),
                    txtDescripcion.getText()
            );
            mensaje("Meta creada");
            actualizarProgreso();
        } catch (Exception e) { mensaje(e.getMessage()); }
    }

    @FXML
    private void agregarAhorro() {
        try {
            servicio.agregarAhorroMetaActual(Double.parseDouble(txtMontoAgregar.getText()));
            mensaje("Ahorro agregado");
            actualizarProgreso();
        } catch (Exception e) { mensaje(e.getMessage()); }
    }

    private void actualizarProgreso() {
        servicio.obtenerMetaActual().ifPresent(m ->
                lblProgreso.setText(String.format("%.2f / %.2f (%.1f%%)",
                        m.getAhorroActual(),
                        m.getObjetivo(),
                        m.getPorcentaje()))
        );
    }

    private void mensaje(String m) {
        new Alert(Alert.AlertType.INFORMATION, m).show();
    }
}


