package org.example.repository;

public class FirebaseRepository {

    public FirebaseRepository() {

    }
}
