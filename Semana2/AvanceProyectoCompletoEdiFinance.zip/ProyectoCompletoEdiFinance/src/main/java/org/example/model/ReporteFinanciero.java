package org.example.model;

import java.time.LocalDate;

public class ReporteFinanciero {

    private String id;
    private double totalIngresos;
    private double totalGastos;
    private double balance;
    private LocalDate fechaGeneracion;

    public ReporteFinanciero(String id, double totalIngresos, double totalGastos) {
        this.id = id;
        this.totalIngresos = totalIngresos;
        this.totalGastos = totalGastos;
        this.balance = totalIngresos - totalGastos;
        this.fechaGeneracion = LocalDate.now();
    }

    public String getId() {
        return id;
    }

    public double getTotalIngresos() {
        return totalIngresos;
    }

    public double getTotalGastos() {
        return totalGastos;
    }

    public double getBalance() {
        return balance;
    }

    public LocalDate getFechaGeneracion() {
        return fechaGeneracion;
    }
}
