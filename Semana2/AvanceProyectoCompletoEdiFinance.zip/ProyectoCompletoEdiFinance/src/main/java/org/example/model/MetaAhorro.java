package org.example.model;

import java.time.LocalDate;

public class MetaAhorro {

    private String id;
    private double objetivo;
    private double ahorroActual;
    private LocalDate fechaLimite;
    private String descripcion;

    public MetaAhorro(String id, double objetivo, LocalDate fechaLimite, String descripcion) {
        this.id = id;
        this.objetivo = objetivo;
        this.ahorroActual = 0;
        this.fechaLimite = fechaLimite;
        this.descripcion = descripcion;
    }

    public String getId() {
        return id;
    }

    public double getObjetivo() {
        return objetivo;
    }

    public double getAhorroActual() {
        return ahorroActual;
    }

    public LocalDate getFechaLimite() {
        return fechaLimite;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void agregarAhorro(double monto) {
        if (monto <= 0) {
            throw new IllegalArgumentException("El monto debe ser mayor a 0.");
        }
        ahorroActual += monto;
    }
}
