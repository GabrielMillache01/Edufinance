package org.example.model;


import java.time.LocalDate;

public class Gasto extends Transaccion {

    public Gasto(String id, double monto, LocalDate fecha, String descripcion) {
        super(id, monto, fecha, descripcion);
    }

    @Override
    public void validar() {
        if (monto <= 0) {
            throw new IllegalArgumentException("El monto del gasto debe ser mayor a 0.");
        }
    }
}
