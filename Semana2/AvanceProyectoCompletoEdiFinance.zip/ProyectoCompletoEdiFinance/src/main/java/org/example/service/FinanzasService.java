package org.example.service;

import org.example.model.Estudiante;
import org.example.model.Gasto;
import org.example.model.Ingreso;
import org.example.model.MetaAhorro;
import org.example.model.ReporteFinanciero;
import org.example.repository.FirebaseRepository;

import java.util.ArrayList;
import java.util.List;

public class FinanzasService {

    private Estudiante estudiante;
    private FirebaseRepository firebaseRepository;

    private List<Ingreso> ingresos;
    private List<Gasto> gastos;
    private List<MetaAhorro> metas;

    public FinanzasService(Estudiante estudiante, FirebaseRepository firebaseRepository) {
        this.estudiante = estudiante;
        this.firebaseRepository = firebaseRepository;

        this.ingresos = new ArrayList<>();
        this.gastos = new ArrayList<>();
        this.metas = new ArrayList<>();
    }

    public void agregarIngreso(Ingreso ingreso) {
        if (ingreso == null) {
            throw new IllegalArgumentException("El ingreso no puede ser nulo.");
        }
        ingresos.add(ingreso);
    }

    public double getTotalIngresos() {
        return ingresos.stream()
                .mapToDouble(Ingreso::getMonto)
                .sum();
    }

    // Después agregamos:
    // - Métodos de gastos
    // - Métodos de metas
    // - Generar reporte
    // - Conexión con Firebase
}



